import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Seleniumtest {

    public static ChromeOptions options;

    public static WebDriver driver;

    @BeforeTest
    public static void Setup() {

        options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/src/test/resources/chromedriver.exe");

        driver = new ChromeDriver(options);

        driver.get("https://tradiumpro.com/");

    }


    @Test
    void teststeps() throws InterruptedException {




        driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/section/div/header/div/a")).click();
        Thread.sleep(1000);




        driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("paulpobitra22@gmail.com");
            driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("Pobitra13!!");
            driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div[2]/div[2]/div/form/button")).click();


        driver.navigate().refresh();




        driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("paulpobitra22@gmai.com");
        driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("Pobitra123!!");
        driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div[2]/div[2]/div/form/button")).click();

        driver.navigate().refresh();


        //Forget passwor portion
        //driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div[2]/div[2]/div/div[2]/a")).click();
        //driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("paulpobitra22@gmail.com");



        driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("paulpobitra22@gmail.com");
        driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("Pobitra123!!");
        driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div[2]/div[2]/div/form/button")).click();

        driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div[2]/div[2]/div/form/button")).click();



    }


}