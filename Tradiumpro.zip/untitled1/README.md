


** Automation using Appium**

This project focuses on automating the testing of a website. It utilizes the Page Object Model (POM) and TestNG as the testing framework. The project also incorporates the Extent Report library to generate comprehensive reports that display the results of passed, failed, and skipped test cases. 

**Overview**

By utilizing the POM design pattern and TestNG, the project offers a structured and scalable approach to test case development and execution. The Extent Report library enhances the reporting capabilities by providing detailed and visually appealing reports.


